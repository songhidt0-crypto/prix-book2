> ## Fix pass — 2026-07-06
> Root cause of `Could not find or load main class "-Xmx64m"`: `android/gradlew` and
> `android/gradlew.bat` were hand-written minimal scripts, not the real Gradle-generated
> wrapper. Their argument handling passed `"-Xmx64m"` (with literal quote characters) to
> `java` unescaped, so the JVM read it as a main-class name instead of a memory flag.
> Both scripts were replaced with the official Gradle 8.4 wrapper scripts. See the
> "Fix pass" section further down for the full list of changes.
>
> ---

# Prix Book — Build Report & Codemagic Setup Guide

**Project:** Prix Book v1.2.0+2  
**Target:** Android debug APK (arm64)  
**Build system:** Codemagic CI/CD (cloud build, no computer required)

---

## What was changed from the original zip

| File | Change | Reason |
|------|--------|--------|
| `codemagic.yaml` | **Added** | Defines the entire cloud build pipeline |
| `android/app/build.gradle` | **Updated** | `versionCode`/`versionName` now use `flutter.versionCode`/`flutter.versionName` from `pubspec.yaml`; explicit `debug` buildType added |
| `.gitignore` | **Updated** | Removed the exclusion of `android/gradlew` and `android/gradlew.bat` so they are committed to GitHub; added `*.jks`/`*.keystore` safety rule |
| `android/gradlew` | **Added** | Shell wrapper script (required by Gradle; was gitignored in original) |
| `android/gradlew.bat` | **Added** | Windows wrapper (committed for completeness) |
| `android/local.properties` | **Kept gitignored** | Generated at build time by the Codemagic script step |
| `scripts/setup.sh` | **Added** | Helper for anyone who wants to build locally first |

---

## Codemagic setup (step by step)

### Step 1 — Push to GitHub

1. Create a new GitHub repository (free account is fine, can be private).
2. If you have a computer or use GitHub's web upload:
   - Upload all files from this zip as-is.
   - The `android/gradle/wrapper/gradle-wrapper.jar` file is **missing** from the zip because it is a binary that couldn't be fetched in the build environment. The Codemagic build script downloads it automatically on first run (Step 2 in `codemagic.yaml`). **This is handled for you — no action needed.**
3. If you only have your phone, use the **GitHub mobile app** or **github.com** in your browser to create the repo and upload the zip contents file by file (or use Working Copy / Spck Editor apps on Android).

> **Tip — easiest phone workflow:**  
> Use [GitLab](https://gitlab.com) instead of GitHub — it lets you upload a whole zip through the web UI at once:  
> New project → Create blank project → once created, use the "+" button → Upload file → select the zip.  
> Codemagic connects to both GitHub and GitLab identically.

### Step 2 — Connect to Codemagic

1. Go to [codemagic.io](https://codemagic.io) and sign up (free — 500 build minutes/month).
2. Click **Add application** → choose your Git provider → select the `prix_book` repository.
3. When asked "How is your project built?", select **Flutter App**.
4. Codemagic will detect `codemagic.yaml` automatically. Click **Finish**.

### Step 3 — Set your email for notifications

Open `codemagic.yaml` in your repo and change:
```yaml
recipients:
  - your@email.com   # ← replace this
```
This is the only manual edit required. Everything else is automated.

### Step 4 — Start a build

In the Codemagic dashboard, click **Start new build** → select the `android-debug` workflow → click **Build**.

Build time: approximately **8–12 minutes** on a fresh cache, **4–6 minutes** with cache.

### Step 5 — Download the APK on your phone

1. When the build finishes, you receive an email with a download link for `app-debug.apk`.
2. Open the email on your Android phone and tap the download link.
3. Before installing, enable **"Install unknown apps"** for your browser or file manager:
   - Android 8+: Settings → Apps → your browser → Install unknown apps → Allow.
4. Tap the downloaded APK to install.

---

## What the build does (codemagic.yaml walkthrough)

```
1. Generate local.properties   → tells Gradle where Flutter SDK and Android SDK are
2. Validate gradle-wrapper.jar → downloads it if missing (first build only, ~60KB)
3. flutter pub get             → installs all Dart/Flutter dependencies
4. flutter test                → runs unit tests (non-blocking)
5. flutter analyze             → static analysis (non-blocking)
6. flutter build apk --debug   → compiles arm64 debug APK
```

**Artifacts collected:**
- `build/app/outputs/flutter-apk/app-debug.apk` — the installable APK

---

## Build environment

| Setting | Value |
|---------|-------|
| Flutter | 3.22.2 (stable) |
| Dart | 3.4.3 (bundled with Flutter 3.22.2) |
| Java | 17 (required by AGP 8.1 + Gradle 8.4) |
| Gradle | 8.4 |
| Android Gradle Plugin | 8.1.0 |
| Kotlin | 1.9.0 |
| Min SDK | API 26 (Android 8.0) |
| Target SDK | API 34 (Android 14) |
| Build machine | Codemagic mac_mini_m2 |

---

## Signing

The debug APK is signed with the **Android debug keystore**, which is auto-generated by the Android SDK on every machine. This means:

- ✅ The APK installs on any Android device.
- ✅ No keys, secrets, or passwords need to be configured anywhere.
- ✅ Nothing sensitive is committed to GitHub.
- ⚠️ This APK **cannot** be uploaded to the Google Play Store. For that, you would need a release keystore (separate setup, not in scope here).

---

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| Build fails at "Validate Gradle wrapper" | Codemagic's network blocked the download — re-trigger build; it usually succeeds on retry |
| `flutter.sdk not set in local.properties` | The "Generate local.properties" script step failed — check the step logs |
| APK installs but crashes immediately | Run `flutter build apk --debug --verbose` locally to see Dart compilation errors |
| `Duplicate class` Kotlin errors | Update `kotlin_version` in `android/build.gradle` to `1.9.22` |
| Build exceeds 30 minutes (free tier) | Split into `--target-platform android-arm` only (smaller, faster) |

---

## Local build (optional — requires Flutter installed on a computer)

```bash
# 1. Run setup script to download gradle-wrapper.jar
bash scripts/setup.sh

# 2. Build debug APK
flutter build apk --debug

# APK is at:
# build/app/outputs/flutter-apk/app-debug.apk
```

---

*Generated by Claude — Prix Book v1.2.0+2 — 2026-06-27*

---

## Fix pass — 2026-07-06 (this session)

| File | Change | Reason |
|------|--------|--------|
| `android/gradlew` | **Replaced** | Old file was a hand-written, non-standard script. Its `DEFAULT_JVM_OPTS='"-Xmx64m" "-Xms64m"'` was expanded unquoted, so `java` received the literal string `"-Xmx64m"` (with quote characters) as an argument, couldn't recognize it as a JVM flag, and tried to run it as the main class → **this was the exact cause of the "Could not find or load main class "-Xmx64m"" error.** Replaced with the official Gradle 8.4 wrapper script, which escapes arguments correctly via `eval`/`xargs`. |
| `android/gradlew.bat` | **Replaced** | Same non-standard script (Windows side). Replaced with the official Gradle 8.4 wrapper batch file for consistency, even though Codemagic builds on macOS/Linux. |
| `android/app/src/main/res/mipmap-*/ic_launcher.png` | **Added (all 5 densities)** | `AndroidManifest.xml` references `@mipmap/ic_launcher`, but no mipmap folders existed anywhere in the project. This would fail the build at the AAPT resource-linking step with "resource mipmap/ic_launcher not found." Generated a simple icon using the app's existing brand colors (navy `#1A3C5E` / green `#2ECC71`) as a placeholder — replace with your real logo whenever ready. |
| `codemagic.yaml` | **Updated** step 2 | The old step blindly downloaded `gradle-wrapper.jar` only if the file was *missing*, and never checked if the download actually succeeded or was a valid archive. The new step validates the jar with `unzip -tq` (real zip test), regenerates it via the CI machine's system Gradle (`gradle wrapper --gradle-version 8.4 --distribution-type all`) if invalid — which also guarantees the wrapper scripts stay in sync with Gradle 8.4 — and only falls back to the raw GitHub download if system Gradle isn't available. It now fails fast with a clear message if the jar still isn't valid, instead of letting a corrupt jar silently reach the build step. |

No files under `lib/` were touched — the app's Dart code was untouched, only the Android/Gradle build scaffolding.
